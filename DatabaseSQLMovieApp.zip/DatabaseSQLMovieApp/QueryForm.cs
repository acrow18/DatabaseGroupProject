﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DatabaseSQLMovieApp
{
    public partial class QueryForm : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDb;Initial Catalog=MovieAppDb;Integrated Security=True");

        public QueryForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Query 1: Show percent capacity by theater
        private void Q1Button_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT MD.MovieName, \r\n\tSUM(CONVERT(DECIMAL(10,2), SM.TicketsSold) / CONVERT(DECIMAL(10,2), SR.Capacity)) * 100 AS PercentageCapacity,\r\n\tSM.StartTime, SM.EndTime\r\nFROM Movies.Theater T\r\n\tINNER JOIN Movies.ShowingRoom SR ON SR.TheaterID = T.TheaterID\r\n\tINNER JOIN Movies.ShowingMovie SM ON SM.RoomID = SR.RoomID\r\n\tINNER JOIN Movies.MovieDetails MD ON MD.MovieDetailsID = SM.MovieDetailsID\r\nWHERE T.TheaterName = @theaterName AND\r\n\tSM.StartTime BETWEEN @startTime AND @endTime\r\nGROUP BY MD.MovieName, SM.StartTime, SM.EndTime\r\nORDER BY PercentageCapacity DESC;", con);
            cmd.Parameters.AddWithValue("@theaterName", Q1NameTB.Text);
            cmd.Parameters.AddWithValue("@startTime", Q1StartTB.Text);
            cmd.Parameters.AddWithValue("@endTime", Q1EndTB.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        // Average Sales
        private void Q2Button_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT MD.Genre, \r\n\tAVG(SM.TicketsSold / SM.TicketPrice) AS AverageSales,\r\n\tCOUNT(TicketsSold) AS TotalTicketsSold,\r\n\tCOUNT(*) AS NumberOfMovies\r\nFROM Movies.MovieDetails MD\r\n\tINNER JOIN Movies.ShowingMovie SM ON SM.MovieDetailsID = MD.MovieDetailsID\r\n\tINNER JOIN Movies.ShowingRoom SR ON SR.RoomID = SM.RoomID\r\n\tINNER JOIN Movies.Theater T ON T.TheaterID = SR.TheaterID\r\nWHERE T.TheaterName = @theaterName\r\nGroup BY MD.Genre, SM.TicketsSold, SM.TicketPrice\r\nORDER BY AverageSales DESC", con);
            cmd.Parameters.AddWithValue("@theaterName", Q2NameTB.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        // Worst performing theaters
        private void Q3Button_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT T.TheaterName, T.TheaterID, \r\n\tSUM(SM.TicketPrice * SM.TicketsSold) AS Profit,\r\n\tRANK() OVER(\r\n\t\t--PARTITION BY TheaterName\r\n\t\tORDER BY SUM(SM.TicketPrice * SM.TicketsSold) ASC\r\n\t\t) AS Ranking\r\nFROM Movies.Theater T\r\n\tINNER JOIN Movies.ShowingRoom SR ON SR.TheaterID = T.TheaterID\r\n\tINNER JOIN Movies.ShowingMovie SM ON SM.RoomID = SR.RoomID\r\nWHERE T.[State] = @state\r\nGROUP BY T.TheaterName, T.TheaterID\r\nORDER BY Ranking ASC", con);
            cmd.Parameters.AddWithValue("@state", Q3StateTB.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        // Top 10 movies from select theater
        private void Q4Button_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT TOP 10\r\n\tMD.MovieName, MD.Genre,\r\n\tSUM(SM.TicketPrice * SM.TicketsSold) AS TotalEarnings,\r\n\tSM.TicketsSold,\r\n\tRank() OVER (ORDER BY SUM(SM.TicketPrice * SM.TicketsSold) DESC) AS EarningRank\r\nFROM Movies.Theater T\r\n\tINNER JOIN Movies.ShowingRoom SR ON SR.TheaterID = T.TheaterID\r\n\tINNER JOIN Movies.ShowingMovie SM ON SM.RoomID = SR.RoomID\r\n\tINNER JOIN Movies.MovieDetails MD ON MD.MovieDetailsID = SM.MovieDetailsID\r\nWHERE T.TheaterName = @theaterName\r\nGROUP BY MD.MovieName, MD.Genre, SM.TicketsSold\r\nORDER BY TotalEarnings DESC", con);
            cmd.Parameters.AddWithValue("@theaterName", Q4NameTB.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
    }
}
