﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseSQLMovieApp
{
    public partial class ShowingMovieForm : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDb;Initial Catalog=MovieAppDb;Integrated Security=True");

        public ShowingMovieForm()
        {
            InitializeComponent();
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Movies].[ShowingMovie]", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //insert button
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into [Movies].[ShowingMovie] values (@RoomID, @MovieDetailsID, @TicketPrice, @TicketsSold, @StartTime, @EndTime)", con);
            cmd.Parameters.AddWithValue("@RoomID", int.Parse(textBox3.Text));
            cmd.Parameters.AddWithValue("@MovieDetailsID", int.Parse(textBox2.Text));
            cmd.Parameters.AddWithValue("@TicketPrice", decimal.Parse(textBox5.Text));
            cmd.Parameters.AddWithValue("@TicketsSold", int.Parse(textBox4.Text));
            DateTime dtt = DateTime.Parse(textBox6.Text);
            string sqlFormattedDate1 = dtt.ToString("yyyy-MM-dd HH:mm:ss.fff");
            cmd.Parameters.AddWithValue("@StartTime", sqlFormattedDate1);
            DateTime dt = DateTime.Parse(textBox7.Text);
            string sqlFormattedDate2 = dt.ToString("yyyy-MM-dd HH:mm:ss.fff");
            cmd.Parameters.AddWithValue("@EndTime", sqlFormattedDate2);
            cmd.ExecuteNonQuery();

            con.Close();
        }

        //refresh button
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Movies].[ShowingMovie]", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        //update button
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Update [Movies].[ShowingMovie] set RoomID=@RoomID, MovieDetailsID=@MovieDetailsID, TicketPrice=@TicketPrice, TicketsSold=@TicketsSold, StartTime=@StartTime, EndTime=@EndTime where MovieID=@MovieID", con);
            cmd.Parameters.AddWithValue("@MovieID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@RoomID", int.Parse(textBox3.Text));
            cmd.Parameters.AddWithValue("@MovieDetailsID", int.Parse(textBox2.Text));
            cmd.Parameters.AddWithValue("@TicketPrice", decimal.Parse(textBox5.Text));
            cmd.Parameters.AddWithValue("@TicketsSold", int.Parse(textBox4.Text));
            DateTime dtt = DateTime.Parse(textBox6.Text);
            string sqlFormattedDate1 = dtt.ToString("yyyy-MM-dd HH:mm:ss.fff");
            cmd.Parameters.AddWithValue("@StartTime", sqlFormattedDate1);
            DateTime dt = DateTime.Parse(textBox7.Text);
            string sqlFormattedDate2 = dt.ToString("yyyy-MM-dd HH:mm:ss.fff");
            cmd.Parameters.AddWithValue("@EndTime", sqlFormattedDate2);
            cmd.ExecuteNonQuery();

            con.Close();
        }

        //search button
        //search by RoomID
        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Movies].[ShowingMovie] where RoomID=@RoomID", con);
            cmd.Parameters.AddWithValue("@RoomID", int.Parse(textBox3.Text));
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
    }
}
