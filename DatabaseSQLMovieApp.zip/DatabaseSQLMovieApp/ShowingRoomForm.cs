﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseSQLMovieApp
{
    public partial class ShowingRoomForm : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDb;Initial Catalog=MovieAppDb;Integrated Security=True");

        public ShowingRoomForm()
        {
            InitializeComponent();
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Movies].[ShowingRoom]", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //insert button
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into [Movies].[ShowingRoom] values (@TheaterID, @Capacity)", con);
            cmd.Parameters.AddWithValue("@TheaterID", int.Parse(textBox3.Text));
            cmd.Parameters.AddWithValue("@Capacity", int.Parse(textBox2.Text));
            
            cmd.ExecuteNonQuery();

            con.Close();
        }

        //update button
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Update [Movies].[ShowingRoom] set Capacity=@Capacity, TheaterID=@TheaterID where RoomID=@RoomID", con);
            cmd.Parameters.AddWithValue("@RoomID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@TheaterID", int.Parse(textBox3.Text));
            cmd.Parameters.AddWithValue("@Capacity", int.Parse(textBox2.Text));
            cmd.ExecuteNonQuery();

            con.Close();
        }

        //refresh button
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Movies].[ShowingRoom]", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        //search button
        //search by theater id
        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Movies].[ShowingRoom] where TheaterID=@TheaterID", con);
            cmd.Parameters.AddWithValue("@TheaterID", int.Parse(textBox3.Text));
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
    }
}
