﻿namespace DatabaseSQLMovieApp
{
    partial class QueryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Q1NameTB = new System.Windows.Forms.TextBox();
            this.Q1StartTB = new System.Windows.Forms.TextBox();
            this.Q1EndTB = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.Q1Button = new System.Windows.Forms.Button();
            this.Q2NameTB = new System.Windows.Forms.TextBox();
            this.Q2Button = new System.Windows.Forms.Button();
            this.Q3StateTB = new System.Windows.Forms.TextBox();
            this.Q3Button = new System.Windows.Forms.Button();
            this.Q4NameTB = new System.Windows.Forms.TextBox();
            this.Q4Button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Q1NameTB
            // 
            this.Q1NameTB.Location = new System.Drawing.Point(141, 36);
            this.Q1NameTB.Name = "Q1NameTB";
            this.Q1NameTB.Size = new System.Drawing.Size(100, 23);
            this.Q1NameTB.TabIndex = 0;
            // 
            // Q1StartTB
            // 
            this.Q1StartTB.Location = new System.Drawing.Point(247, 36);
            this.Q1StartTB.Name = "Q1StartTB";
            this.Q1StartTB.Size = new System.Drawing.Size(100, 23);
            this.Q1StartTB.TabIndex = 1;
            // 
            // Q1EndTB
            // 
            this.Q1EndTB.Location = new System.Drawing.Point(353, 36);
            this.Q1EndTB.Name = "Q1EndTB";
            this.Q1EndTB.Size = new System.Drawing.Size(99, 23);
            this.Q1EndTB.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(1, 301);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(799, 150);
            this.dataGridView1.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Back to Menu";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Q1Button
            // 
            this.Q1Button.Location = new System.Drawing.Point(458, 27);
            this.Q1Button.Name = "Q1Button";
            this.Q1Button.Size = new System.Drawing.Size(117, 39);
            this.Q1Button.TabIndex = 5;
            this.Q1Button.Text = "Percent Capacity";
            this.Q1Button.UseVisualStyleBackColor = true;
            this.Q1Button.Click += new System.EventHandler(this.Q1Button_Click);
            // 
            // Q2NameTB
            // 
            this.Q2NameTB.Location = new System.Drawing.Point(141, 84);
            this.Q2NameTB.Name = "Q2NameTB";
            this.Q2NameTB.Size = new System.Drawing.Size(100, 23);
            this.Q2NameTB.TabIndex = 6;
            // 
            // Q2Button
            // 
            this.Q2Button.Location = new System.Drawing.Point(458, 75);
            this.Q2Button.Name = "Q2Button";
            this.Q2Button.Size = new System.Drawing.Size(117, 39);
            this.Q2Button.TabIndex = 7;
            this.Q2Button.Text = "Average Sales";
            this.Q2Button.UseVisualStyleBackColor = true;
            this.Q2Button.Click += new System.EventHandler(this.Q2Button_Click);
            // 
            // Q3StateTB
            // 
            this.Q3StateTB.Location = new System.Drawing.Point(141, 133);
            this.Q3StateTB.Name = "Q3StateTB";
            this.Q3StateTB.Size = new System.Drawing.Size(100, 23);
            this.Q3StateTB.TabIndex = 8;
            // 
            // Q3Button
            // 
            this.Q3Button.Location = new System.Drawing.Point(458, 125);
            this.Q3Button.Name = "Q3Button";
            this.Q3Button.Size = new System.Drawing.Size(117, 36);
            this.Q3Button.TabIndex = 9;
            this.Q3Button.Text = "Worst Performance";
            this.Q3Button.UseVisualStyleBackColor = true;
            this.Q3Button.Click += new System.EventHandler(this.Q3Button_Click);
            // 
            // Q4NameTB
            // 
            this.Q4NameTB.Location = new System.Drawing.Point(141, 176);
            this.Q4NameTB.Name = "Q4NameTB";
            this.Q4NameTB.Size = new System.Drawing.Size(100, 23);
            this.Q4NameTB.TabIndex = 10;
            // 
            // Q4Button
            // 
            this.Q4Button.Location = new System.Drawing.Point(457, 167);
            this.Q4Button.Name = "Q4Button";
            this.Q4Button.Size = new System.Drawing.Size(118, 36);
            this.Q4Button.TabIndex = 11;
            this.Q4Button.Text = "Top 10 Movies";
            this.Q4Button.UseVisualStyleBackColor = true;
            this.Q4Button.Click += new System.EventHandler(this.Q4Button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(141, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 15);
            this.label1.TabIndex = 12;
            this.label1.Text = "Theater Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(141, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 15);
            this.label2.TabIndex = 13;
            this.label2.Text = "Theater Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(141, 159);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 15);
            this.label3.TabIndex = 14;
            this.label3.Text = "Theater Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(141, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 15);
            this.label4.TabIndex = 15;
            this.label4.Text = "State";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(247, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 15);
            this.label5.TabIndex = 16;
            this.label5.Text = "Start Time";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(353, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 15);
            this.label6.TabIndex = 17;
            this.label6.Text = "End Time";
            // 
            // QueryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Q4Button);
            this.Controls.Add(this.Q4NameTB);
            this.Controls.Add(this.Q3Button);
            this.Controls.Add(this.Q3StateTB);
            this.Controls.Add(this.Q2Button);
            this.Controls.Add(this.Q2NameTB);
            this.Controls.Add(this.Q1Button);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Q1EndTB);
            this.Controls.Add(this.Q1StartTB);
            this.Controls.Add(this.Q1NameTB);
            this.Name = "QueryForm";
            this.Text = "Query1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox Q1NameTB;
        private TextBox Q1StartTB;
        private TextBox Q1EndTB;
        private DataGridView dataGridView1;
        private Button button1;
        private Button Q1Button;
        private TextBox Q2NameTB;
        private Button Q2Button;
        private TextBox Q3StateTB;
        private Button Q3Button;
        private TextBox Q4NameTB;
        private Button Q4Button;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
    }
}