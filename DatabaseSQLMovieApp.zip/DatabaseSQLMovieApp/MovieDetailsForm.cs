﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseSQLMovieApp
{
    public partial class MovieDetailsForm : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDb;Initial Catalog=MovieAppDb;Integrated Security=True");

        public MovieDetailsForm()
        {
            InitializeComponent();
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Movies].[MovieDetails]", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //insert button
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into [Movies].[MovieDetails] values (@MovieName, @Review, @Description, @Studio, @MPAARating, @Genre)", con);
            cmd.Parameters.AddWithValue("@MovieName", textBox2.Text);
            cmd.Parameters.AddWithValue("@Review", textBox3.Text);
            cmd.Parameters.AddWithValue("@Description", textBox4.Text);
            cmd.Parameters.AddWithValue("@Studio", textBox5.Text);
            cmd.Parameters.AddWithValue("@MPAARating", textBox6.Text);
            cmd.Parameters.AddWithValue("@Genre", textBox7.Text);
            cmd.ExecuteNonQuery();

            con.Close();
        }

        //refresh button
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Movies].[MovieDetails]", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        //update button
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Update [Movies].[MovieDetails] set MovieName=@MovieName, Review=@Review, Description=@Description, Studio=@Studio, MPAARating=@MPAARating, Genre=@Genre where MovieDetailsID=@MovieDetailsID", con);
            cmd.Parameters.AddWithValue("@MovieName", textBox2.Text);
            cmd.Parameters.AddWithValue("@Review", textBox3.Text);
            cmd.Parameters.AddWithValue("@Description", textBox4.Text);
            cmd.Parameters.AddWithValue("@Studio", textBox5.Text);
            cmd.Parameters.AddWithValue("@MPAARating", textBox6.Text);
            cmd.Parameters.AddWithValue("@Genre", textBox7.Text);
            cmd.Parameters.AddWithValue("@MovieDetailsID", int.Parse(textBox8.Text));
            cmd.ExecuteNonQuery();

            con.Close();
        }

        //search button
        //search by showingid
        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Movies].[MovieDetails] where MovieName=@MovieName", con);
            cmd.Parameters.AddWithValue("@MovieName", textBox2.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
    }
}
