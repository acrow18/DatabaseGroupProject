namespace DatabaseSQLMovieApp
{
    public partial class MenuForm : Form
    {

        BindingSource theaterBindingSource = new BindingSource();

        public MenuForm()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            
            ShowingRoomForm f2 = new ShowingRoomForm();
            f2.ShowDialog();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            ShowingMovieForm f3 = new ShowingMovieForm();
            f3.ShowDialog();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            MovieDetailsForm f4 = new MovieDetailsForm();
            f4.ShowDialog();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            TheaterForm f5 = new TheaterForm();
            f5.ShowDialog();
        }

        private void queryButton_Click(object sender, EventArgs e)
        {
            QueryForm f6 = new QueryForm();
            f6.ShowDialog();
        }
    }
}