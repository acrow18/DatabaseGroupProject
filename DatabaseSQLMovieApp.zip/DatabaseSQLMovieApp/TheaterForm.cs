﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseSQLMovieApp
{
    public partial class TheaterForm : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDb;Initial Catalog=MovieAppDb;Integrated Security=True");

        public TheaterForm()
        {
            InitializeComponent();
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Movies].[Theater]", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //insert button
        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into [Movies].[Theater] values (@TheaterName, @Zipcode, @Street, @State)", con);
            cmd.Parameters.AddWithValue("@TheaterName", textBox2.Text);
            cmd.Parameters.AddWithValue("@Zipcode", int.Parse(textBox3.Text));
            cmd.Parameters.AddWithValue("@Street", textBox4.Text);
            cmd.Parameters.AddWithValue("@State", textBox5.Text);
            cmd.ExecuteNonQuery();

            con.Close();
        }

        //update button
        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Update [Movies].[Theater] set TheaterName=@TheaterName, Zipcode=@Zipcode, Street=@Street, State=@State where TheaterID=@TheaterID", con);
            cmd.Parameters.AddWithValue("@TheaterID", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@TheaterName", textBox2.Text);
            cmd.Parameters.AddWithValue("@Zipcode", int.Parse(textBox3.Text));
            cmd.Parameters.AddWithValue("@Street", textBox4.Text);
            cmd.Parameters.AddWithValue("@State", textBox5.Text);
            cmd.ExecuteNonQuery();

            con.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        //refresh button
        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Movies].[Theater]", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        //search button
        //search by theater name
        private void button6_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from [Movies].[Theater] where TheaterName=@TheaterName", con);
            cmd.Parameters.AddWithValue("@TheaterName", textBox2.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
    }
}
